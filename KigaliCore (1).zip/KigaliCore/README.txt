# KigaliCore

KigaliCore is a frontend prototype for a Kigali tourism, economic promotion, ticketing and community-ideas platform.

## Files
- index.html — public website
- css/style.css — public website styling
- js/script.js — public interactions and demo storage
- pages/admin.html — admin dashboard
- css/admin.css — dashboard styling
- js/admin.js — dashboard data display

## Contact configured
Email: bonnaanalberti@gmail.com
Phone: 0787753883

## Payment prototype
- USD
- RWF / MoMo

The current version is a frontend prototype. It stores demo bookings and ideas in browser localStorage. It does NOT process real money.

## Next production stage
Connect a secure backend/database, administrator authentication, real MoMo/payment provider, email receipts, and server-side validation.


UPDATED PLACE GALLERY
- The public Places gallery now uses real Kigali locations and real photographs from Wikimedia Commons where noted.
- Place cards include descriptions, addresses, map buttons, information/official links, and ticket/admission information.
- The Admin Dashboard > Attractions section lets an administrator add custom places using a photo URL, description, map URL, ticket prices and other details.
- Custom places are stored in browser localStorage under kigalicore_places for this prototype.
- Before commercial launch, confirm photo licenses and keep the displayed attribution/license information for every image.
- Default place facts and current visitor information were checked against Visit Rwanda, Kigali Genocide Memorial, and Inema Arts Center sources on September 26, 2026.


UPGRADE - BRAND & SPECIAL BUILDINGS
- Added a custom KigaliCore SVG logo in images/kigalicore-logo.svg.
- Added a dedicated Special Buildings section featuring Kigali Convention Centre, Kigali City Tower, BK Arena, Amahoro Stadium and Ubumwe Grande Hotel.
- Added map and information links for each building.
- Photos use Wikimedia Commons source files/redirects; verify the license/source before a commercial launch.
- The Admin Dashboard retains the Add Place function for adding additional places to the public gallery.
