function get(key){try{return JSON.parse(localStorage.getItem(key)||"[]")}catch(e){return []}}
function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]))}
function render(){
 const bookings=get("kigalicore_bookings"), ideas=get("kigalicore_ideas");
 document.getElementById("bookingCount").textContent=bookings.length;
 document.getElementById("ideaCount").textContent=ideas.length;
 document.getElementById("bookingRows").innerHTML=bookings.length?bookings.slice().reverse().map(b=>`<tr><td>${esc(b.id)}</td><td>${esc(b.experience)}</td><td>${esc(b.email)}</td><td>${esc(b.currency)}</td><td>${esc(b.paymentMethod)}</td><td class="status">${esc(b.status)}</td></tr>`).join(""):`<tr><td colspan="6">No bookings yet. Create a booking from the public website.</td></tr>`;
 document.getElementById("ideaList").innerHTML=ideas.length?ideas.slice().reverse().map(i=>`<div class="idea"><b>${esc(i.name)}</b> · ${esc(i.email)}<p>${esc(i.text)}</p><small>${new Date(i.createdAt).toLocaleString()} · ${esc(i.status)}</small></div>`).join(""):`<div class="idea">No community ideas yet.</div>`;
}
function clearBookings(){if(confirm("Clear demo bookings from this browser?")){localStorage.removeItem("kigalicore_bookings");render()}}
function addDemoAd(){const ads=get("kigalicore_ads");ads.push({name:"Local Kigali Business",description:"Example economic advertisement. Replace this with real business information.",createdAt:new Date().toISOString()});localStorage.setItem("kigalicore_ads",JSON.stringify(ads));renderAds()}
function renderAds(){const ads=get("kigalicore_ads");document.getElementById("adList").innerHTML=ads.length?ads.map(a=>`<div class="ad"><b>${esc(a.name)}</b><p>${esc(a.description)}</p></div>`).join(""):`<div class="ad">No advertisements yet. Use “Add demo ad” to test the dashboard.</div>`}
function renderPlaces(){
 const places=get('kigalicore_places'); const box=document.getElementById('placeAdminList'); if(!box)return;
 box.innerHTML=places.length?places.map(p=>`<div class="admin-place"><div><b>${esc(p.name)}</b><span>${esc(p.category)}</span><p>${esc(p.address)}</p><small>USD: ${esc(p.usd)} · RWF: ${esc(p.rwf)}</small></div><button class="danger-btn" onclick="deletePlace('${esc(p.id)}')">Delete</button></div>`).join(''):'<div class="idea">No custom places yet. Default verified places are already visible on the public website.</div>';
}
function deletePlace(id){const places=get('kigalicore_places').filter(p=>p.id!==id);localStorage.setItem('kigalicore_places',JSON.stringify(places));renderPlaces()}
function setupPlaceForm(){
 const form=document.getElementById('placeForm'); if(!form)return;
 form.addEventListener('submit',e=>{e.preventDefault();
  const place={id:'custom-'+Date.now(),name:document.getElementById('placeName').value.trim(),category:document.getElementById('placeCategory').value,description:document.getElementById('placeDescription').value.trim(),address:document.getElementById('placeAddress').value.trim(),image:document.getElementById('placeImage').value.trim(),map:document.getElementById('placeMap').value.trim(),website:document.getElementById('placeWebsite').value.trim()||document.getElementById('placeMap').value.trim(),usd:document.getElementById('placeUsd').value.trim(),rwf:document.getElementById('placeRwf').value.trim(),photoCredit:'Added by KigaliCore admin'};
  const places=get('kigalicore_places'); places.push(place); localStorage.setItem('kigalicore_places',JSON.stringify(places)); form.reset(); document.getElementById('placeFormStatus').textContent='Place added. Refresh the public website to see it.'; renderPlaces();
 });
}
render();renderAds();renderPlaces();setupPlaceForm();
