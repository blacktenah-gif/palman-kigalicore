const defaultKigaliPlaces = [
  {
    id:'kcc', name:'Kigali Convention Centre', category:'Landmark',
    description:'An iconic Kigali events venue with distinctive Rwandan-inspired architecture, about 5 km from the city centre.',
    address:'Kigali Convention Centre, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Kigali%20Convention%20center%2C%20Rwanda.jpg',
    photoCredit:'Jim Joel / Wikimedia Commons (CC BY-SA 4.0)',
    map:'https://www.google.com/maps/search/?api=1&query=Kigali+Convention+Centre+Rwanda',
    website:'https://visitrwanda.com/meet-in-rwanda/kigali-convention-centre/',
    usd:'Contact venue', rwf:'Contact venue'
  },
  {
    id:'kgm', name:'Kigali Genocide Memorial', category:'Culture',
    description:'A place of remembrance and learning in Gisozi with exhibitions, gardens, archives and guided experiences.',
    address:'KG 14 Ave, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Genocide%20Memorial%20site%20of%20Gisozi%20Kigali%20Genocide%20Memorial%20021.jpg',
    photoCredit:'Wikimedia Commons photograph; verify current licensing before commercial publication',
    map:'https://www.google.com/maps/search/?api=1&query=Kigali+Genocide+Memorial+KG+14+Ave+Kigali',
    website:'https://kgm.rw/visit/',
    usd:'Free entrance; packages from $20', rwf:'Free entrance; packages from Rwf 30,000'
  },
  {
    id:'kimironko', name:'Kimironko Market', category:'Market',
    description:'A major Kigali market known for fresh produce, fabrics, clothing, crafts and everyday local commerce.',
    address:'Kimironko Market, Gasabo District, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Kimironko%20Market%2C%20Kigali.jpg',
    photoCredit:'Talley Beth Gale / Wikimedia Commons (CC BY-SA 4.0)',
    map:'https://www.google.com/maps/search/?api=1&query=Kimironko+Market+Kigali+Rwanda',
    website:'https://visitrwanda.com/wp-content/uploads/2024/07/Rwanda-destination-Guide.pdf',
    usd:'No admission price listed', rwf:'No admission price listed'
  },
  {
    id:'inema', name:'Inema Arts Center', category:'Culture',
    description:'A Kacyiru creative hub with galleries, artist studios, classes, events and a café.',
    address:'KG 563 St, Kacyiru, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Inema%20Art%20Center.jpg',
    photoCredit:'Jim Joel / Wikimedia Commons (CC BY-SA 4.0)',
    map:'https://www.google.com/maps/search/?api=1&query=Inema+Arts+Center+KG+563+St+Kacyiru+Kigali',
    website:'https://inemaartcenter.com/visit/',
    usd:'Free entry', rwf:'Free entry'
  },
  {
    id:'mount-kigali', name:'Mount Kigali View', category:'Nature',
    description:'A Kigali hillside area known for elevated views and access to outdoor experiences around Mount Kigali.',
    address:'Mount Kigali, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/Mount%20Kigali%20view%20hill.jpg',
    photoCredit:'Ig250 / Wikimedia Commons (CC BY-SA 4.0)',
    map:'https://www.google.com/maps/search/?api=1&query=Mount+Kigali+Rwanda',
    website:'https://visitrwanda.com/discover-rwanda/',
    usd:'No general entrance fee listed', rwf:'No general entrance fee listed'
  },
  {
    id:'nyamirambo', name:'St Charles Lwanga Church, Nyamirambo', category:'Neighborhood',
    description:'A documented Nyamirambo landmark in one of Kigali’s long-established and lively urban neighbourhoods.',
    address:'Nyamirambo Sector, Nyarugenge District, Kigali, Rwanda',
    image:'https://commons.wikimedia.org/wiki/Special:Redirect/file/St%20Charles%20Lwanga%20-%20Nyamirambo%20%28Right%20side%29.jpg',
    photoCredit:'Celestin KANUMA / Wikimedia Commons (CC BY-SA 4.0)',
    map:'https://www.google.com/maps/search/?api=1&query=St+Charles+Lwanga+Church+Nyamirambo+Kigali',
    website:'https://visitrwanda.com/wp-content/uploads/2024/07/Rwanda-destination-Guide.pdf',
    usd:'No visitor ticket listed', rwf:'No visitor ticket listed'
  }
];

function getCustomPlaces(){
  try { return JSON.parse(localStorage.getItem('kigalicore_places') || '[]'); }
  catch(e){ return []; }
}
function getAllKigaliPlaces(){ return [...defaultKigaliPlaces, ...getCustomPlaces()]; }
function escapeHtml(value){
  return String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
}
function renderKigaliGallery(filter='All'){
  const grid=document.getElementById('kigaliGallery'); if(!grid)return;
  const places=getAllKigaliPlaces();
  const shown=filter==='All'?places:places.filter(p=>p.category===filter);
  grid.innerHTML=shown.map(p=>`<article class="place-card">
    <div class="place-image-wrap"><img src="${escapeHtml(p.image)}" alt="${escapeHtml(p.name)}" loading="lazy" onerror="this.src='https://placehold.co/1200x800?text=KigaliCore+Place'">
      <span class="place-category">${escapeHtml(p.category)}</span>
    </div>
    <div class="place-content">
      <h3>${escapeHtml(p.name)}</h3>
      <p>${escapeHtml(p.description)}</p>
      <p class="place-address">📍 ${escapeHtml(p.address)}</p>
      <div class="place-price"><span><b>USD</b> ${escapeHtml(p.usd)}</span><span><b>RWF</b> ${escapeHtml(p.rwf)}</span></div>
      <div class="place-actions"><a class="place-link" href="${escapeHtml(p.map)}" target="_blank" rel="noopener">📍 Map</a><a class="place-link" href="${escapeHtml(p.website)}" target="_blank" rel="noopener">Official/info →</a></div>
      <small class="photo-credit">Photo: ${escapeHtml(p.photoCredit)}</small>
    </div>
  </article>`).join('') || '<p class="empty-gallery">No places match this filter yet.</p>';
}

document.addEventListener('DOMContentLoaded',()=>{
  renderKigaliGallery();
  document.querySelectorAll('.gallery-filter').forEach(b=>b.addEventListener('click',()=>{
    document.querySelectorAll('.gallery-filter').forEach(x=>x.classList.remove('active'));
    b.classList.add('active'); renderKigaliGallery(b.dataset.filter);
  }));
});
