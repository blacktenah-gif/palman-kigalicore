const $ = id => document.getElementById(id);

const menuToggle = $("menuToggle");
const mainNav = $("mainNav");
if (menuToggle) menuToggle.addEventListener("click", () => mainNav.classList.toggle("open"));

const currency = $("currency");
const momoWrap = $("momoWrap");
currency.addEventListener("change", () => {
  momoWrap.style.display = currency.value === "RWF" ? "block" : "none";
});
momoWrap.style.display = "block";

function showModal(title, message) {
  $("modalTitle").textContent = title;
  $("modalMessage").textContent = message;
  $("modal").classList.add("show");
  $("modal").setAttribute("aria-hidden", "false");
}
function closeModal() {
  $("modal").classList.remove("show");
  $("modal").setAttribute("aria-hidden", "true");
}
$("closeModal").addEventListener("click", closeModal);
$("modalOk").addEventListener("click", closeModal);

$("ticketForm").addEventListener("submit", e => {
  e.preventDefault();
  const email = $("customerEmail").value.trim();
  const method = currency.value === "RWF" ? "RWF / MoMo" : "USD";
  const experience = $("experience").value;
  const momo = $("momo").value.trim();

  if (currency.value === "RWF" && !/^07\d{8}$/.test(momo)) {
    showModal("Check MoMo number", "Please enter a valid Rwanda-style MoMo number, for example 0787753883.");
    return;
  }

  const booking = {
    id: "KC-" + Date.now(),
    experience, email, currency: currency.value,
    paymentMethod: method, momo: currency.value === "RWF" ? momo : "",
    status: "PENDING",
    createdAt: new Date().toISOString()
  };
  const bookings = JSON.parse(localStorage.getItem("kigalicore_bookings") || "[]");
  bookings.push(booking);
  localStorage.setItem("kigalicore_bookings", JSON.stringify(bookings));

  showModal("Booking created", `Your ${experience} booking was recorded as ${method}. Real payment processing will be connected in the backend. A receipt can be sent to ${email} after payment is confirmed.`);
  e.target.reset();
  momoWrap.style.display = "block";
});

$("ideaForm").addEventListener("submit", e => {
  e.preventDefault();
  const idea = {
    id: "IDEA-" + Date.now(),
    name: $("ideaName").value.trim(),
    email: $("ideaEmail").value.trim(),
    text: $("ideaText").value.trim(),
    status: "NEW",
    createdAt: new Date().toISOString()
  };
  const ideas = JSON.parse(localStorage.getItem("kigalicore_ideas") || "[]");
  ideas.push(idea);
  localStorage.setItem("kigalicore_ideas", JSON.stringify(ideas));
  showModal("Idea submitted", "Thank you. Your idea has been saved for administrator review.");
  e.target.reset();
});
